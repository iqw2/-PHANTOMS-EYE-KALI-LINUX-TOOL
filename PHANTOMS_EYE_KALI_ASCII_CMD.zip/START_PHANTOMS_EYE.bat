@echo off
chcp 65001 >nul
title PHANTOMS EYE - KALI ASCII CMD
python -m pip install -r requirements.txt
python phantoms_eye.py
pause
