PHANTOMS EYE — KALI ASCII CMD
=============================

Installation:
1. Extract the ZIP into a folder.
2. Install Python 3.10+ if needed.
3. Double-click START_PHANTOMS_EYE.bat.

The script attempts to install dnspython for extended DNS record queries.
The UI uses the supplied Kali-dragon ASCII text at startup, no flashing animation,
and three side-by-side numbered tool panels.

Tools 01 and 02:
01 IP DEEP LOOKUP
02 URL DEEP SEARCH

These attempt to return as much available public data as possible: IP classification,
DNS records, resolved IPv4/IPv6, approximate Geo-IP, RDAP registration/network data,
HTTP status and response headers, TLS certificate information, page metadata, and
previews of common public files. Data availability depends on target responses, network
access, and public API providers. Missing data and errors are shown rather than invented.

Other tools cover DNS, reverse DNS, RDAP, HTTP headers, TLS, SHA-256, Base64, JSON,
email headers, local logs, localhost-only port checks, URL metadata, standard public
files, IP classification and utility functions.

Safety:
- Only ordinary DNS, public RDAP, HTTP and TLS requests are used.
- Port checks are limited to 127.0.0.1.
- Geo-IP is approximate.
- Missing security headers alone do not prove a vulnerability.
- Use only for lawful, authorized defensive analysis.
