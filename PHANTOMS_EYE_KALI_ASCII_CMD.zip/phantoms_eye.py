# -*- coding: utf-8 -*-
"""PHANTOMS EYE — Kali ASCII CMD toolkit; passive, public-information lookups only."""
import os, sys, time, json, re, socket, ssl, hashlib, base64, urllib.parse, urllib.request, urllib.error, ipaddress
from pathlib import Path

try:
    import dns.resolver
    HAS_DNS = True
except ImportError:
    HAS_DNS = False

Y = "\033[93m"; O = "\033[38;5;208m"; R = "\033[91m"; G = "\033[92m"
C = "\033[96m"; W = "\033[97m"; D = "\033[90m"; P = "\033[95m"; X = "\033[0m"
CLEAR = "\033[2J\033[H"
ART = r"""@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@%%%%%#*+=-:::-=*%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#*=:.:=*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*-.%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@%#*=-:..::--======--:::-@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@###%@@@@@@@@@@@@@@@@@@@@@@%+-....**@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%+==+*%%@@@@@@@#*@@@@@@@@@%%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@#*+*%@@@@@@@@@@@@@@@@= .:---+#%@@@##@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@%+=%@@@@@@@@@@@@@@@@@@@%:.:=##%#*-...=%@%*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@*+@@@@@@@@@@@@@@@@@@@@@@@-.-@@@@@@@@@@@@#:...#*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=.*@@@@@@@@@@@@@@@@@%  :@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%.-@@@@@@@@@@@@@@@@@@@#-.:@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%.=@@@@@@@@@@@@@@@@@@@@@@%:.*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%.:@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=.-@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*..+@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*-. .::---==+*#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%%#*+:.....-#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=:%@#::@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%-%@@%=*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#+@@@@+@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=@@@@%@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@+@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@+@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"""

TOOLS_LEFT = [
    (1, "IP DEEP LOOKUP", "Maximum public IP details"),
    (2, "URL DEEP SEARCH", "Maximum URL/domain details"),
    (3, "DNS RECORDS", "A, AAAA, CNAME, MX, NS, TXT, SOA, CAA"),
    (4, "REVERSE DNS", "PTR and reverse hostname"),
    (5, "RDAP LOOKUP", "Domain/IP registration data"),
    (6, "HTTP HEADERS", "Status, redirects, response headers"),
    (7, "TLS CERTIFICATE", "Certificate and connection details"),
    (8, "SHA-256 FILE HASH", "Hash a local file"),
]
TOOLS_MID = [
    (9, "BASE64 TOOL", "Encode/decode Base64"),
    (10, "JSON INSPECTOR", "Validate and format JSON"),
    (11, "EMAIL HEADER", "Analyze pasted mail headers"),
    (12, "LOCAL LOG ANALYZER", "Summarize a local log file"),
    (13, "LOCALHOST PORT CHECK", "Checks only 127.0.0.1"),
    (14, "PUBLIC IP INFO", "Lookup your public IP via provider"),
    (15, "URL METADATA", "HTML title/meta/links"),
    (16, "STANDARD FILES", "robots.txt, sitemap, security.txt"),
]
TOOLS_RIGHT = [
    (17, "DNS CACHE / RESOLVE", "System resolver results"),
    (18, "CERTIFICATE FINGERPRINT", "SHA-256 certificate fingerprint"),
    (19, "IP CLASSIFIER", "Private/global/reserved/loopback"),
    (20, "HTTP SECURITY HEADERS", "Common defensive header review"),
    (21, "ENCODE / DECODE URL", "URL quote/unquote"),
    (22, "TIMESTAMP", "Convert Unix timestamp"),
    (23, "ENVIRONMENT INFO", "Python/OS/runtime"),
    (24, "HELP / LEGAL", "Usage and safe-use notes"),
]

def api(url, headers=None, timeout=12, limit=2_000_000):
    req=urllib.request.Request(url, headers=headers or {"User-Agent":"PhantomsEye/1.0 (public defensive lookup)", "Accept":"*/*"})
    start=time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body=r.read(limit+1)
            return {"ok":True,"status":r.status,"final_url":r.geturl(),"headers":dict(r.headers.items()),
                    "body":body[:limit],"truncated":len(body)>limit,"elapsed_ms":round((time.perf_counter()-start)*1000,2)}
    except urllib.error.HTTPError as e:
        try: body=e.read(limit)
        except Exception: body=b""
        return {"ok":False,"status":e.code,"final_url":e.geturl(),"headers":dict(e.headers.items()) if e.headers else {},
                "body":body,"error":str(e),"elapsed_ms":round((time.perf_counter()-start)*1000,2)}
    except Exception as e:
        return {"ok":False,"error":f"{type(e).__name__}: {e}","elapsed_ms":round((time.perf_counter()-start)*1000,2)}

def api_json(url):
    r=api(url, {"User-Agent":"PhantomsEye/1.0","Accept":"application/json"})
    try: r["json"]=json.loads(r.get("body",b"").decode("utf-8","replace"))
    except Exception: pass
    r.pop("body",None)
    return r

def dump(title, obj):
    print(C+"\n["+title+"]"+X)
    print(json.dumps(obj,indent=2,ensure_ascii=False,default=str))

def get_url(raw):
    if "://" not in raw: raw="https://"+raw
    p=urllib.parse.urlsplit(raw)
    if not p.hostname: raise ValueError("Invalid URL/hostname.")
    return raw,p

def dns_info(host):
    out={"host":host,"resolver":"dnspython" if HAS_DNS else "system resolver fallback","records":{}}
    if HAS_DNS:
        for typ in ("A","AAAA","CNAME","MX","NS","TXT","SOA","CAA"):
            try:
                a=dns.resolver.resolve(host,typ,lifetime=4)
                out["records"][typ]=[{"value":x.to_text(),"ttl_seconds":a.rrset.ttl} for x in a]
            except Exception as e: out["records"][typ]={"unavailable":str(e)}
    else:
        for fam,typ in ((socket.AF_INET,"A"),(socket.AF_INET6,"AAAA")):
            try: out["records"][typ]=sorted({x[4][0] for x in socket.getaddrinfo(host,None,fam,socket.SOCK_STREAM)})
            except Exception as e: out["records"][typ]={"unavailable":str(e)}
        out["records"]["additional_types"]="Install dnspython to query MX/NS/TXT/SOA/CAA/CNAME and TTL."
    try:
        out["system_reverse_names"]=sorted({socket.gethostbyaddr(x[4][0])[0] for x in socket.getaddrinfo(host,None)})
    except Exception as e: out["system_reverse_names"]={"unavailable":str(e)}
    return out

def rdap(target,is_ip):
    kind="ip" if is_ip else "domain"
    url=f"https://rdap.org/{kind}/{urllib.parse.quote(target,safe=':./')}"
    r=api_json(url)
    return {"source":url,**{k:v for k,v in r.items() if k!="headers"}}

def geo(ip):
    url="http://ip-api.com/json/"+urllib.parse.quote(ip)+"?fields=status,message,continent,continentCode,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,offset,currency,isp,org,as,asname,reverse,mobile,proxy,hosting,query"
    r=api_json(url)
    return {"source":"ip-api.com; approximate/provider-dependent geo-IP","result":r.get("json",r.get("error"))}

def tls(host,port=443):
    out={"host":host,"port":port}
    try:
        ctx=ssl.create_default_context()
        with socket.create_connection((host,port),timeout=8) as s:
            with ctx.wrap_socket(s,server_hostname=host) as t:
                der=t.getpeercert(binary_form=True)
                out.update({"tls_version":t.version(),"cipher":t.cipher(),"certificate":t.getpeercert(),
                            "sha256_fingerprint":hashlib.sha256(der).hexdigest().upper(),"certificate_bytes":len(der)})
    except Exception as e: out["error"]=f"{type(e).__name__}: {e}"
    return out

def classify_ip(ip):
    a=ipaddress.ip_address(ip)
    return {"address":str(a),"version":a.version,"compressed":getattr(a,"compressed",str(a)),
        "exploded":getattr(a,"exploded",str(a)),"reverse_pointer":a.reverse_pointer,
        "is_global":a.is_global,"is_private":a.is_private,"is_reserved":a.is_reserved,
        "is_loopback":a.is_loopback,"is_link_local":a.is_link_local,"is_multicast":a.is_multicast,
        "is_unspecified":a.is_unspecified}

def ip_lookup():
    raw=input(C+"IP address: "+X).strip()
    try: info=classify_ip(raw)
    except ValueError: print(R+"Invalid IP address."+X); return
    dump("IP CLASSIFICATION",info)
    try: dump("REVERSE DNS",{"hostname":socket.gethostbyaddr(raw)[0],"aliases":socket.gethostbyaddr(raw)[1]})
    except Exception as e: dump("REVERSE DNS",{"unavailable":str(e)})
    dump("APPROXIMATE GEO-IP",geo(raw))
    dump("RDAP / NETWORK REGISTRATION",rdap(raw,True))
    print(D+"Geo-IP is approximate. Private/reserved addresses may have no public registry information."+X)

def parse_page(body, final_url):
    html=body.decode("utf-8","replace")
    def meta(key):
        pat=r'<meta\b[^>]*(?:name|property)\s*=\s*["\']'+re.escape(key)+r'["\'][^>]*>'
        m=re.search(pat,html,re.I)
        if not m:return None
        c=re.search(r'content\s*=\s*["\']([^"\']*)',m.group(),re.I)
        return c.group(1) if c else None
    title=re.search(r"<title[^>]*>(.*?)</title\s*>",html,re.I|re.S)
    lang=re.search(r"<html\b[^>]*\blang\s*=\s*['\"]([^'\"]+)",html,re.I)
    canonical=re.search(r'<link\b[^>]*rel\s*=\s*["\']canonical["\'][^>]*href\s*=\s*["\']([^"\']+)',html,re.I)
    links=re.findall(r'<a\b[^>]*href\s*=\s*["\']([^"\']+)',html,re.I)
    return {"title":re.sub(r"\s+"," ",title.group(1)).strip() if title else None,
        "language":lang.group(1) if lang else None,"description":meta("description"),"keywords":meta("keywords"),
        "robots":meta("robots"),"og_title":meta("og:title"),"og_description":meta("og:description"),
        "og_site_name":meta("og:site_name"),"twitter_card":meta("twitter:card"),
        "canonical":urllib.parse.urljoin(final_url,canonical.group(1)) if canonical else None,
        "links_found":len(links),"links_sample":[urllib.parse.urljoin(final_url,x) for x in links[:100]],
        "html_bytes_analyzed":len(body)}

SEC_HEADERS=["Strict-Transport-Security","Content-Security-Policy","X-Content-Type-Options","X-Frame-Options",
"Referrer-Policy","Permissions-Policy","Cross-Origin-Opener-Policy","Cross-Origin-Resource-Policy","Cross-Origin-Embedder-Policy"]

def url_lookup():
    raw=input(C+"URL / domain: "+X).strip()
    try: normalized,p=get_url(raw)
    except Exception as e: print(R+str(e)+X); return
    host=p.hostname
    dump("URL IDENTIFICATION",{"input":raw,"normalized_url":normalized,"scheme":p.scheme,"hostname":host,
        "port":p.port or (443 if p.scheme=="https" else 80),"path":p.path or "/","query":p.query or None,
        "fragment":p.fragment or None,"TLD":host.rsplit(".",1)[-1] if "." in host else None,
        "IDNA_hostname":host.encode("idna").decode("ascii")})
    dump("DNS RECORDS",dns_info(host))
    ips=[]
    try:
        for item in socket.getaddrinfo(host,None):
            ip=item[4][0]
            if ip not in ips: ips.append(ip)
    except Exception as e: print(R+"Resolution error: "+str(e)+X)
    dump("RESOLVED IP ADDRESSES",ips)
    dump("DOMAIN RDAP",rdap(host,False))
    for ip in ips:
        dump("IP DETAILS: "+ip,{"classification":classify_ip(ip),"geo_ip":geo(ip),"rdap":rdap(ip,True)})
    result=api(normalized,{"User-Agent":"Mozilla/5.0 (compatible; PhantomsEye/1.0)","Accept":"text/html,application/xhtml+xml,*/*"})
    summary={k:v for k,v in result.items() if k not in ("body",)}
    h=result.get("headers",{})
    summary["security_header_review"]={name:next((v for k,v in h.items() if k.lower()==name.lower()),"NOT PRESENT in this response") for name in SEC_HEADERS}
    dump("HTTP RESPONSE + SELECTED SECURITY HEADERS",summary)
    if h: dump("ALL HTTP RESPONSE HEADERS",h)
    if p.scheme=="https": dump("TLS CERTIFICATE",tls(host,p.port or 443))
    else: dump("TLS CERTIFICATE",{"note":"Input URL uses HTTP; TLS was not silently substituted."})
    if result.get("body"): dump("PAGE METADATA",parse_page(result["body"],result.get("final_url",normalized)))
    base=f"{p.scheme}://{host}"+(f":{p.port}" if p.port else "")
    for path in ("/robots.txt","/sitemap.xml","/security.txt","/.well-known/security.txt","/manifest.json","/favicon.ico"):
        rr=api(urllib.parse.urljoin(base+"/",path.lstrip("/")),timeout=5,limit=100000)
        dump("PUBLIC FILE "+path,{"status":rr.get("status"),"final_url":rr.get("final_url"),
          "content_type":rr.get("headers",{}).get("Content-Type"),"bytes":len(rr.get("body",b"")),
          "error":rr.get("error"),"preview":rr.get("body",b"")[:1200].decode("utf-8","replace") if rr.get("body") else None})
    print(Y+"Notes: geo-IP is approximate; missing headers alone do not prove a vulnerability; API fields may be incomplete."+X)

def dns_tool():
    host=input("Hostname/domain: ").strip()
    if host: dump("DNS",dns_info(host))

def reverse_dns():
    target=input("IP or hostname: ").strip()
    try:
        ipaddress.ip_address(target)
        dump("PTR",{"reverse_pointer":ipaddress.ip_address(target).reverse_pointer,"result":socket.gethostbyaddr(target)})
    except ValueError:
        try: dump("RESOLUTION",{"host":target,"addresses":sorted({x[4][0] for x in socket.getaddrinfo(target,None)})})
        except Exception as e: dump("ERROR",{"error":str(e)})
    except Exception as e: dump("ERROR",{"error":str(e)})

def rdap_tool():
    target=input("IP or domain: ").strip()
    try: ipaddress.ip_address(target); is_ip=True
    except ValueError: is_ip=False
    dump("RDAP",rdap(target,is_ip))

def http_headers():
    raw=input("URL: ").strip()
    try: u,_=get_url(raw)
    except Exception as e: print(R+str(e)+X); return
    r=api(u); dump("HTTP RESULT",{k:v for k,v in r.items() if k!="body"})
    if r.get("headers"): dump("ALL RESPONSE HEADERS",r["headers"])
    if r.get("body"): print(r["body"][:1200].decode("utf-8","replace"))

def tls_tool():
    host=input("Hostname (optionally host:port): ").strip()
    if not host:return
    if "://" in host:
        _,p=get_url(host); dump("TLS",tls(p.hostname,p.port or 443))
    else:
        port=443
        if host.count(":")==1:
            host,port_s=host.rsplit(":",1)
            try:port=int(port_s)
            except ValueError:port=443
        dump("TLS",tls(host,port))

def hash_tool():
    path=input("Local file path: ").strip().strip('"')
    try:
        h=hashlib.sha256(); size=0
        with open(path,"rb") as f:
            for b in iter(lambda:f.read(1024*1024),b""): h.update(b); size+=len(b)
        dump("SHA-256",{"path":path,"bytes":size,"sha256":h.hexdigest()})
    except Exception as e: print(R+str(e)+X)

def base64_tool():
    mode=input("Encode or decode [e/d]: ").strip().lower(); val=input("Text: ")
    try:
        if mode=="d":
            b=base64.b64decode(val,validate=True); dump("DECODED",{"utf8":b.decode("utf-8","replace"),"hex":b.hex(),"bytes":len(b)})
        else: print(base64.b64encode(val.encode()).decode())
    except Exception as e: print(R+str(e)+X)

def json_tool():
    try: print(json.dumps(json.loads(input("Paste JSON: ")),indent=2,ensure_ascii=False))
    except Exception as e: print(R+"JSON error: "+str(e)+X)

def email_tool():
    print("Paste email headers; blank line ends input.")
    lines=[]
    while True:
        s=input()
        if not s:break
        lines.append(s)
    fields={}
    for line in lines:
        if ":" in line and not line[:1].isspace():
            k,v=line.split(":",1); fields.setdefault(k.strip(),[]).append(v.strip())
    dump("EMAIL HEADER SUMMARY",{"fields":fields,"notes":["Headers can be forged; authentication results depend on the receiving mail system."]})

def log_tool():
    path=input("Local log file: ").strip().strip('"')
    try:
        lines=Path(path).read_text(encoding="utf-8",errors="replace").splitlines()
        pats={"error":r"\berror\b|\bexception\b|\bfail(ed|ure)?\b","warning":r"\bwarn(ing)?\b",
              "auth":r"login|authentication|unauthorized|forbidden|failed password","network":r"timeout|connection refused|dns"}
        dump("LOG ANALYSIS",{"file":path,"lines":len(lines),"counts":{k:sum(bool(re.search(p,x,re.I)) for x in lines) for k,p in pats.items()},
          "matching_samples":[{"line":i+1,"text":line[:400]} for i,line in enumerate(lines) if any(re.search(p,line,re.I) for p in pats.values())][:100]})
    except Exception as e: print(R+str(e)+X)

def localhost_ports():
    raw=input("Localhost ports comma-separated [22,80,443,445,3389]: ").strip() or "22,80,443,445,3389"
    try: ports=sorted({int(x.strip()) for x in raw.split(",") if 1<=int(x.strip())<=65535})
    except Exception: print(R+"Invalid ports."+X); return
    results=[]
    for port in ports:
        s=socket.socket(); s.settimeout(.35)
        try: state="OPEN" if s.connect_ex(("127.0.0.1",port))==0 else "closed / filtered"
        finally: s.close()
        results.append({"host":"127.0.0.1","port":port,"result":state})
    dump("LOCALHOST ONLY",results)

def public_ip():
    r=api("https://api.ipify.org?format=json")
    dump("PUBLIC IP PROVIDER RESPONSE",{"result":r.get("json"),"status":r.get("status"),"error":r.get("error")})

def metadata_tool():
    raw=input("URL: ").strip()
    try:u,_=get_url(raw)
    except Exception as e:print(R+str(e)+X);return
    r=api(u)
    if r.get("body"):dump("METADATA",parse_page(r["body"],r.get("final_url",u)))
    else:dump("ERROR",{"error":r.get("error"),"status":r.get("status")})

def standard_files():
    raw=input("URL/domain: ").strip()
    try:u,p=get_url(raw)
    except Exception as e:print(R+str(e)+X);return
    base=f"{p.scheme}://{p.hostname}"+(f":{p.port}" if p.port else "")
    for path in ("/robots.txt","/sitemap.xml","/security.txt","/.well-known/security.txt","/manifest.json","/favicon.ico"):
        r=api(urllib.parse.urljoin(base+"/",path.lstrip("/")),timeout=5,limit=100000)
        dump(path,{"status":r.get("status"),"content_type":r.get("headers",{}).get("Content-Type"),
            "bytes":len(r.get("body",b"")),"error":r.get("error"),
            "preview":r.get("body",b"")[:1500].decode("utf-8","replace") if r.get("body") else None})

def resolver_tool():
    host=input("Hostname: ").strip()
    try: dump("SYSTEM RESOLVER",{"hostname":host,"results":socket.getaddrinfo(host,None)})
    except Exception as e: dump("ERROR",{"error":str(e)})

def cert_fingerprint():
    host=input("HTTPS hostname: ").strip()
    dump("CERTIFICATE FINGERPRINT",tls(host))

def ip_classifier():
    val=input("IP: ").strip()
    try: dump("IP CLASSIFICATION",classify_ip(val))
    except Exception as e: print(R+str(e)+X)

def security_headers():
    raw=input("URL: ").strip()
    try:u,_=get_url(raw)
    except Exception as e:print(R+str(e)+X);return
    r=api(u)
    h=r.get("headers",{})
    dump("SECURITY HEADERS",{"http_status":r.get("status"),**{name:next((v for k,v in h.items() if k.lower()==name.lower()),"NOT PRESENT") for name in SEC_HEADERS},
        "note":"Missing headers are not by themselves proof of a vulnerability."})

def url_encode():
    s=input("Text: ")
    mode=input("Encode/decode [e/d]: ").strip().lower()
    print(urllib.parse.unquote(s) if mode=="d" else urllib.parse.quote(s,safe=""))

def timestamp_tool():
    raw=input("Unix timestamp: ").strip()
    try: print(datetime.fromtimestamp(float(raw),timezone.utc).isoformat()+" UTC")
    except Exception as e: print(R+str(e)+X)

def env_info():
    dump("ENVIRONMENT",{"python":sys.version,"platform":sys.platform,"os_name":os.name,"dnspython_available":HAS_DNS})

def help_tool():
    print("Passive/public-information analysis only. Use only for lawful, authorized purposes.")
    print("URL/IP Deep Lookup collects DNS, RDAP, approximate geo-IP, HTTP headers, TLS and page metadata.")
    print("No aggressive scanning of remote hosts is performed. Port check is restricted to 127.0.0.1.")

ACTIONS={1:ip_lookup,2:url_lookup,3:dns_tool,4:reverse_dns,5:rdap_tool,6:http_headers,7:tls_tool,
8:hash_tool,9:base64_tool,10:json_tool,11:email_tool,12:log_tool,13:localhost_ports,14:public_ip,
15:metadata_tool,16:standard_files,17:resolver_tool,18:cert_fingerprint,19:ip_classifier,20:security_headers,
21:url_encode,22:timestamp_tool,23:env_info,24:help_tool}

def box(title, items, width=28):
    top="+"+"-"*(width-2)+"+"
    print(Y+top+X)
    print(Y+"| "+O+title[:width-4].ljust(width-4)+Y+" |"+X)
    print(Y+"+"+"-"*(width-2)+"+"+X)
    for n,name,desc in items:
        line=f"{n:02d} > {name}"
        print(Y+"| "+O+line[:width-4].ljust(width-4)+Y+" |"+X)
    print(Y+top+X)

def draw_menu():
    print(CLEAR,end="")
    print(O+"PHANTOMS EYE — ASCII PURPLE CMD PRO".center(100)+X)
    print(Y+"="*100+X)
    print(ART)
    print(Y+"="*100+X)
    # Three adjacent category panels; keep readable in typical Windows Terminal width.
    cols=[TOOLS_LEFT,TOOLS_MID,TOOLS_RIGHT]
    width=32
    print(Y+"+"+"-"*30+"+"+"+"+"-"*30+"+"+"+"+"-"*30+"+"+X)
    titles=["[1] CORE LOOKUPS","[2] ANALYSIS TOOLS","[3] EXTRA UTILITIES"]
    for title in titles:
        print(Y+"| "+O+title.ljust(28)+Y+" |"+X,end="")
    print()
    print(Y+"+"+"-"*30+"+"+"+"+"-"*30+"+"+"+"+"-"*30+"+"+X)
    rows=max(map(len,cols))
    for i in range(rows):
        for col in cols:
            if i<len(col):
                n,name,desc=col[i]
                line=f"{n:02d} > {name}"
            else: line=""
            print(Y+"| "+O+line[:28].ljust(28)+Y+" |"+X,end="")
        print()
    print(Y+"+"+"-"*30+"+"+"+"+"-"*30+"+"+"+"+"-"*30+"+"+X)
    print(D+"Enter a tool number, 'help', 'clear' or 'exit'. Full lookup reports can be long."+X)

def main():
    if os.name=="nt":
        os.system("")
        os.system("title PHANTOMS EYE — KALI ASCII CMD")
    while True:
        draw_menu()
        choice=input(G+"\nPHANTOMS_EYE > "+X).strip().lower()
        if choice in ("exit","quit","q"):break
        if choice=="clear":continue
        if choice=="help":help_tool();input("\nEnter to continue...");continue
        try:n=int(choice)
        except ValueError: print(R+"Unknown command."+X);time.sleep(.7);continue
        if n not in ACTIONS: print(R+"Unknown tool number."+X);time.sleep(.7);continue
        print(CLEAR,end="")
        try:ACTIONS[n]()
        except KeyboardInterrupt: print(R+"\nCancelled."+X)
        except Exception as e: print(R+f"\nTool error: {type(e).__name__}: {e}"+X)
        input("\nEnter to return to menu...")
    print(O+"PHANTOMS EYE closed. Stay safe."+X)

if __name__=="__main__":main()
